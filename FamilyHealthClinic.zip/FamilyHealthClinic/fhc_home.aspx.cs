﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class famili_Health_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["logid"] = "";
    }
    protected void btn_login_Click(object sender, EventArgs e)
    {
        if (txtid.Text.ToString().Equals("doctor") && txtpass.Text.ToString().Equals("fhcdoctor"))
        {
            Session["logid"] = txtid.Text.ToString();
            Response.Redirect("fhc_doctor.aspx"); }
        else
        if (txtid.Text.ToString() != "" && txtpass.Text.ToString() != "")
        { checklogin(); }
        else { Response.Write("<script>alert('Please fill all the details');</script>"); }
    }
    private void checklogin()
    {

        string str = ConfigurationManager.ConnectionStrings["fhcConnectionString"].ConnectionString;
        SqlConnection sqlcon = new SqlConnection(str);
        try
        {
            sqlcon.Open();

            string sqlquery = "select * from tbl_emp where econtact='" + txtid.Text.ToString() + "' and epassword='" + txtpass.Text.ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sqlquery, sqlcon);
            SqlDataReader dr = cmd1.ExecuteReader();
            if (dr.Read())
            {
                Session["logid"] = txtid.Text.ToString();
                sqlcon.Close();
                Response.Write("<script>alert('Login Success');</script>");
               Server.Transfer("fhc_reception.aspx");
               

            }

        }
        catch (Exception ex)
        {
           //  Response.Write("<script>alert('Invalid Details');</script>");
           //  Response.Write(ex.Message);
        }
       
    }
}