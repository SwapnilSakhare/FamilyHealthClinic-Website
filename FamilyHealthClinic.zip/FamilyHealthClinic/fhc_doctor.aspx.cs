﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class famili_Health_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["logid"] == null)
        { Response.Redirect("fhc_home.aspx"); }
        Response.Write(DateTime.Now.ToShortDateString());
        Session["apdate"] = DateTime.Now.ToShortDateString();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["sdata"] = GridView1.SelectedRow.Cells[1].Text;
        //  Session["spname"] = GridView1.SelectedRow.Cells[2].Text;
        Response.Redirect("fhc_dignose.aspx");
        //  Response.Write(Session["sdata"].ToString());
    }
}