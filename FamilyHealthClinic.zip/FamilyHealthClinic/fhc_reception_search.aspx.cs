﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class famili_Health_Home : System.Web.UI.Page
{
  
  
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["logid"] == null)
        { Response.Redirect("fhc_home.aspx"); }
        Response.Write(DateTime.Now.ToShortDateString());
        Session["apdate"] = DateTime.Now.ToShortDateString();
        
    }
    protected void btn_search_Click(object sender, EventArgs e)
    {
        if (txtsname.Text.ToString() != "" && txtscontact.Text.ToString() =="")
        { Session["sname"] = txtsname.Text.ToString();
      
        Response.Redirect("fhc_reception_search.aspx");
        }
        else if(txtsname.Text.ToString() == "" && txtscontact.Text.ToString() !="")
        { Session["scontact"] = txtscontact.Text.ToString();
      
        Response.Redirect("fhc_reception_search.aspx");
        }
        else if (txtsname.Text.ToString() != "" && txtscontact.Text.ToString() != "") 
        {
            Session["sname"] = txtsname.Text.ToString();
            Session["scontact"] = txtscontact.Text.ToString();
        }
        else {
            Session["sname"] = "";
            Session["scontact"] = "";
           
            Response.Redirect("fhc_reception_search.aspx"); }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["sdata"] = GridView1.SelectedRow.Cells[1].Text;
      //  Session["spname"] = GridView1.SelectedRow.Cells[2].Text;
        Response.Redirect("fhc_book_appointment.aspx");
        //  Response.Write(Session["sdata"].ToString());
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
      //  Session["spname"] = GridView2.SelectedRow.Cells[2].Text;
        Session["sdata"] = GridView2.SelectedRow.Cells[1].Text;
        Response.Redirect("fhc_book_appointment.aspx");
      //  Response.Write(Session["sdata"].ToString());
    }
    protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["sdata"] = GridView3.SelectedRow.Cells[1].Text;
      //  Session["spname"] = GridView3.SelectedRow.Cells[2].Text;
        Response.Redirect("fhc_book_appointment.aspx");
      //  Response.Write(Session["sdata"].ToString());
    }
}