﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class famili_Health_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["logid"] == null)
        { Response.Redirect("fhc_home.aspx"); }
        Response.Write(DateTime.Now.ToShortDateString());
        Session["apdate"] = DateTime.Now.ToShortDateString();
    }
   
    protected void btn_add_Click(object sender, EventArgs e)
    {
        if (txtname.Text.ToString() != "" && txtcontact.Text.ToString() != "" && txtemail.Text.ToString() != "" && txtaddress.Text.ToString() != "" && txtpass.Text.ToString() != "")
        {
            Add_Employee();
        }
        else { Response.Write("<script>alert('All fields required...');</script>"); }
    }
    protected void Add_Employee()
    {
        try
        {

            string str = ConfigurationManager.ConnectionStrings["fhcConnectionString"].ConnectionString;
            SqlConnection sqlcon = new SqlConnection(str);

            sqlcon.Open();
            //command 1
            String strid = "select max(eid) from tbl_emp";
            SqlCommand cmd = new SqlCommand(strid, sqlcon);
            int rowid = Convert.ToInt32(cmd.ExecuteScalar());
            rowid = rowid + 1;
            //String eid = rowid.ToString().Trim();


            //command 2
            string sqlquery = "insert into tbl_emp values('" + rowid + "','" + txtname.Text.ToString() + "','" + txtcontact.Text.ToString() + "','" + txtemail.Text.ToString() +
            "','" + txtaddress.Text.ToString() + "','" + txtpass.Text.ToString() + "')";
            SqlCommand cmd1 = new SqlCommand(sqlquery, sqlcon);


            int k = cmd1.ExecuteNonQuery();
            if (k != 0)
            {
                Response.Write("<script>alert('Employee Added');</script>");
                
                Server.Transfer("fhc_doctor_employee.aspx");

            }
            else
            {
                Response.Write("<script>alert('allready exist');</script>");

            }


            sqlcon.Close();


        }
        catch (Exception ex)
        {
            // Response.Write("<script>alert('contact administrator');</script>");
            // Response.Write(ex.Message);
        }
    }
}