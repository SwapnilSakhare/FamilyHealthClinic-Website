﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class famili_Health_Home : System.Web.UI.Page
{
  
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["logid"] == null)
        { Response.Redirect("fhc_home.aspx"); }
        Response.Write(DateTime.Now.ToShortDateString());
        Session["apdate"] = DateTime.Now.ToShortDateString();
       view_data() ;
       
    }
   
    protected void view_data()
    {

        string str = ConfigurationManager.ConnectionStrings["fhcConnectionString"].ConnectionString;
        SqlConnection sqlcon = new SqlConnection(str);
        try
        {
            sqlcon.Open();

            string sqlquery = "select * from tbl_patient where pid='" + Session["sdata"].ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sqlquery, sqlcon);
            SqlDataReader dr = cmd1.ExecuteReader();
            if (dr.Read())
            {

                txtid.Text = ("Patient Id : "+dr["pid"].ToString());
                txtname.Text = ("Patient Name : " + dr["pname"].ToString());
                Session["aname"] = ( dr["pname"].ToString());
                txtcontact.Text = ("Patient Contact : " + dr["pcontact"].ToString());
                txtemail.Text = ("Patient Email : " + dr["pemail"].ToString());
                txtaddress.Text = ("Patient Address : " + dr["paddress"].ToString());
                

            }

        }
        catch (Exception ex)
        {
            Response.Write("contact administrator");
            // Response.Write(ex.Message);
        }
        sqlcon.Close();
    }
    
    protected void btn_save_Click(object sender, EventArgs e)
    {
        if (txtdname.Text.ToString() != "" && txtdpres.Text.ToString() != "")
        {
            save_details();
        }
        else {
            Response.Write("<script>alert('Please fill Disease details');</script>");
        }
    }
    protected void save_details()
    {

        
            try
            {

                string str = ConfigurationManager.ConnectionStrings["fhcConnectionString"].ConnectionString;
                SqlConnection sqlcon = new SqlConnection(str);

                sqlcon.Open();
                //command 1
                String strid = "select max(did) from tbl_disease";
                SqlCommand cmd = new SqlCommand(strid, sqlcon);
                int rowid = Convert.ToInt32(cmd.ExecuteScalar());
                rowid = rowid + 1;
                //String eid = rowid.ToString().Trim();


                //command 2
                string sqlquery = "insert into tbl_disease values('" + rowid + "','" + Session["sdata"].ToString() + "','" + DateTime.Now.ToShortDateString() +
                "','" + txtdname.Text.ToString() + "','" + txtdpres.Text.ToString() + "')";
                SqlCommand cmd1 = new SqlCommand(sqlquery, sqlcon);


                int k = cmd1.ExecuteNonQuery();
                if (k != 0)
                {
                    txtdpres.Text = "";
                    txtdname.Text = "";
                    Response.Write("<script>alert('Saved Successfully');</script>");
                    sqlcon.Close();
                    update_appointment();

                }
                else
                {
                    Response.Write("<script>alert('ERROR');</script>");

                }

            }
            catch (Exception ex)
            {
              //  Response.Write("<script>alert('contact administrator');</script>");
              //  Response.Write(ex.Message);
            }
        }

    protected void update_appointment()
    {
        try
        {

            string str = ConfigurationManager.ConnectionStrings["fhcConnectionString"].ConnectionString;
            SqlConnection sqlcon = new SqlConnection(str);

            sqlcon.Open();

            string sqlquery = "Update tbl_appointment set adone='" + "Yes" + "' where apid='" + Session["sdata"].ToString() + "' and adate='" + Session["apdate"].ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sqlquery, sqlcon);


            int k = cmd1.ExecuteNonQuery();
            if (k != 0)
            {
                Server.Transfer("fhc_book_appointment.aspx");

            }
            else
            {
                Response.Write("<script>alert('ERROR');</script>");

            }


            sqlcon.Close();


        }
        catch (Exception ex)
        {
          //  Response.Write("<script>alert('contact administrator');</script>");
            //Response.Write(ex.Message);
        }
    }
    
    
}