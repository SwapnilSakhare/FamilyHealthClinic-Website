﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class famili_Health_Home : System.Web.UI.Page
{
  
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["logid"] == null)
        { Response.Redirect("fhc_home.aspx"); }
        Response.Write(DateTime.Now.ToShortDateString());
        Session["apdate"] = DateTime.Now.ToShortDateString();
       view_data() ;
       
    }
   
    protected void view_data()
    {

        string str = ConfigurationManager.ConnectionStrings["fhcConnectionString"].ConnectionString;
        SqlConnection sqlcon = new SqlConnection(str);
        try
        {
            sqlcon.Open();

            string sqlquery = "select * from tbl_patient where pid='" + Session["sdata"].ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sqlquery, sqlcon);
            SqlDataReader dr = cmd1.ExecuteReader();
            if (dr.Read())
            {

                txtid.Text = ("Patient Id : "+dr["pid"].ToString());
                txtname.Text = ("Patient Name : " + dr["pname"].ToString());
                Session["aname"] = ( dr["pname"].ToString());
                txtcontact.Text = ("Patient Contact : " + dr["pcontact"].ToString());
                txtemail.Text = ("Patient Email : " + dr["pemail"].ToString());
                txtaddress.Text = ("Patient Address : " + dr["paddress"].ToString());
                

            }

        }
        catch (Exception ex)
        {
           // Response.Write("contact administrator");
            // Response.Write(ex.Message);
        }
        sqlcon.Close();
    }
    protected void btn_give_appointment_Click(object sender, EventArgs e)
    {
        save_appointment();
    }
    protected void save_appointment()
    {
        try
        {

            string str = ConfigurationManager.ConnectionStrings["fhcConnectionString"].ConnectionString;
            SqlConnection sqlcon = new SqlConnection(str);

            sqlcon.Open();
            //command 1
            String strid = "select max(aid) from tbl_appointment";
            SqlCommand cmd = new SqlCommand(strid, sqlcon);
            int rowid = Convert.ToInt32(cmd.ExecuteScalar());
            rowid = rowid + 1;
            //String eid = rowid.ToString().Trim();


            //command 2
            string sqlquery = "insert into tbl_appointment values('" + rowid + "','" + Session["sdata"].ToString() + "','" + Session["aname"].ToString() + "','" + DateTime.Now.ToShortDateString() +
            "','" + "NO" + "')";
            SqlCommand cmd1 = new SqlCommand(sqlquery, sqlcon);


            int k = cmd1.ExecuteNonQuery();
            if (k != 0)
            {
                Response.Write("<script>alert('Appointment Booked');</script>");

            }
            else
            {
                Response.Write("<script>alert('ERROR');</script>");

            }


            sqlcon.Close();


        }
        catch (Exception ex)
        {
           // Response.Write("<script>alert('contact administrator');</script>");
            //Response.Write(ex.Message);
        }
    }


    
    
    
}